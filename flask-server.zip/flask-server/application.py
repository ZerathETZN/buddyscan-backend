from flask_cors import CORS
from flask import Flask, jsonify
import boto3

application = Flask(__name__)
# CORS(app)


# Create S3 client
s3 = boto3.client("s3")
bucket = "sagemaker-s3-database"

# @app.route("/files", methods=["GET"])
# def list_files():
#     """List all files in the S3 bucket"""
#     try:
#         response = s3.list_objects_v2(Bucket=bucket)

#         if "Contents" in response:
#             files = [obj["Key"] for obj in response["Contents"]]
#             return jsonify({"files": files}), 200
#         else:
#             return jsonify({"message": "No files found in bucket"}), 404

#     except Exception as e:
#         return jsonify({"error": str(e)}), 500
@application.route("/files", methods=["GET"])
def list_files():
    """List all files in the S3 bucket"""
    try:
        response = s3.list_objects_v2(Bucket=bucket)

        if "Contents" in response:
            files = [obj["Key"] for obj in response["Contents"]]
            print("S3 Bucket Files:", files)  # <-- This will print to your Flask server console
            return jsonify({"files": files}), 200
        
        else:
            print("No files found in bucket")  # <-- Print if empty
            return jsonify({"message": "No files found in bucket"}), 404

    except Exception as e:
        print("Error accessing S3:", e)  # <-- Print error
        return jsonify({"error": str(e)}), 500


# @app.route("/download/<filename>", methods=["GET"])
# def download_file(filename):
#     """Download a specific file from S3"""
#     try:
#         # Save locally (optional)
#         s3.download_file(bucket, filename, filename)
#         return jsonify({"message": f"{filename} downloaded successfully"}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500
@application.route("/get-text/<filename>", methods=["GET"])
def get_text(filename):
    try:
        obj = s3.get_object(Bucket=BUCKET_NAME, Key=filename)
        content = obj["Body"].read().decode("utf-8")
        return jsonify({"filename": filename, "content": content})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    application.run(debug=True)